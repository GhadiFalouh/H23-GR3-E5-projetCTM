from .models import Member, Action, PorteFeuille
import requests


def verifier(user, member):
    return
